#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// =====================
// MOTOR PINS
// =====================
#define IN1 7
#define IN2 6
#define IN3 14
#define IN4 8

// =====================
// SENSOR PINS
// =====================
const int sensorPins[6] = {11, 1, 9, 18, 5, 2};
int sensorValues[6];
int weights[6] = {200, 1000, 2000, 3000, 4000, 4800};

// =====================
// GLOBAL VARIABLES
// =====================
bool robotRunning = false;  // Line following mode state
int baseSpeed = 130;
int pivotSpeed = 140;
float Kp = 0.62;
float Kd = 0.5;

float error = 0, previousError = 0, PIDvalue = 0;
int maxSpeed = 255;

// =====================
// MOTOR CONTROL FUNCTION
// =====================
// Defined here so the Bluetooth class can see it
void setMotorSpeed(int left, int right) {
  left = constrain(left, -maxSpeed, maxSpeed);
  right = constrain(right, -maxSpeed, maxSpeed);

  if (left > 0) {
    analogWrite(IN1, left);
    analogWrite(IN2, 0);
  } else {
    analogWrite(IN1, 0);
    analogWrite(IN2, -left);
  }

  if (right > 0) {
    analogWrite(IN3, right);
    analogWrite(IN4, 0);
  } else {
    analogWrite(IN3, 0);
    analogWrite(IN4, -right);
  }
}

// =====================
// BLUETOOTH CONFIG
// =====================
#define SERVICE_UUID           "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define CHARACTERISTIC_UUID_RX "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"

class MyCallbacks: public BLECharacteristicCallbacks {
    void onWrite(BLECharacteristic *pCharacteristic) {
      String value = pCharacteristic->getValue().c_str();
      if (value.length() > 0) {
        char cmd = value[0];

        // --- TANK DRIVE (DS4) ---
        if (cmd == 'T') {
          int commaIndex = value.indexOf(',');
          if (commaIndex != -1) {
            int l = value.substring(1, commaIndex).toInt();
            int r = value.substring(commaIndex + 1).toInt();
            robotRunning = false;
            setMotorSpeed(l * 2.5, r * 2.5);
          }
        }
        // --- JOYSTICK COMMAND HANDLING ---
        else if (cmd == 'J') {
          // Format: "J100,50" (X,Y)
          int commaIndex = value.indexOf(',');
          if (commaIndex != -1) {
            int x = value.substring(1, commaIndex).toInt();
            int y = value.substring(commaIndex + 1).toInt();

            robotRunning = false; // Manual mode overrides line following

            int left = y + x;
            int right = y - x;
            setMotorSpeed(left * 2.5, right * 2.5); // Scale -100..100 to -250..250
          }
        }
        // --- PID TUNING & START/STOP LOGIC ---
        else {
          int startIndex = 0;
          while (startIndex < value.length()) {
              char c = value[startIndex];
              int nextSpace = value.indexOf(' ', startIndex + 1);
              if (nextSpace == -1) nextSpace = value.length();
              float val = value.substring(startIndex + 1, nextSpace).toFloat();

              if (c == 'P') Kp = val;
              else if (c == 'D') Kd = val;
              else if (c == 'B') baseSpeed = (int)val;
              else if (c == 'V') pivotSpeed = (int)val;
              else if (c == 'S') {
                robot_running = (val > 0.5);
                if (!robotRunning) setMotorSpeed(0, 0);
              }
              startIndex = nextSpace + 1;
          }
        }
      }
    }
};

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);

  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);

  BLEDevice::init("LABUBOT");
  BLEServer *pServer = BLEDevice::createServer();
  BLEService *pService = pServer->createService(SERVICE_UUID);
  BLECharacteristic *pRxChar = pService->createCharacteristic(
                                         CHARACTERISTIC_UUID_RX,
                                         BLECharacteristic::PROPERTY_WRITE
                                       );
  pRxChar->setCallbacks(new MyCallbacks());
  pService->start();
  pServer->getAdvertising()->start();
  Serial.println("LABUBOT Ready...");
}

int readLine() {
  long weightedSum = 0, total = 0;
  for (int i = 0; i < 6; i++) {
    sensorValues[i] = 4095 - analogRead(sensorPins[i]);
    weightedSum += (long)sensorValues[i] * weights[i];
    total += sensorValues[i];
  }
  return (total == 0) ? 2500 : (weightedSum / total);
}

void loop() {
  if (!robotRunning) return; // Wait for START or manual joystick input handled in callback

  int position = readLine();
  error = position - 2500;
  if (abs(error) < 100) error = 0;
  error = constrain(error, -2000, 2000);

  if (abs(error) > 1800) {
    setMotorSpeed(error > 0 ? pivotSpeed : -pivotSpeed, error > 0 ? -pivotSpeed : pivotSpeed);
    return;
  }

  PIDvalue = (Kp * error) + (Kd * (error - previousError) * 0.5);
  previousError = error;

  int maxTurn = constrain(70 + abs(error) / 15, 70, 130);
  PIDvalue = constrain(PIDvalue, -maxTurn, maxTurn);

  int adjustedBase = constrain(baseSpeed - (abs(error) / 10), 90, baseSpeed);
  setMotorSpeed(adjustedBase + PIDvalue, adjustedBase - PIDvalue);
}
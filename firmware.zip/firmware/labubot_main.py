import bluetooth
import machine
import time
import struct
from machine import Pin, PWM, ADC

# =====================
# MOTOR PINS & SETUP
# =====================
in1 = PWM(Pin(7), freq=5000)
in2 = PWM(Pin(6), freq=5000)
in3 = PWM(Pin(14), freq=5000)
in4 = PWM(Pin(8), freq=5000)

# =====================
# SENSOR PINS & SETUP
# =====================
sensor_pins = [11, 1, 9, 18, 5, 2]
sensors = [ADC(Pin(p)) for p in sensor_pins]
for s in sensors:
    s.atten(ADC.ATTN_11DB)

weights = [200, 1000, 2000, 3000, 4000, 4800]

# =====================
# GLOBAL VARIABLES
# =====================
robot_running = False
base_speed = 130
pivot_speed = 140
kp = 0.62
kd = 0.5
error = 0
prev_error = 0
max_speed = 255

# =====================
# BLE UART SERVICE
# =====================
_UART_UUID = bluetooth.UUID("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
_UART_RX = (bluetooth.UUID("6E400002-B5A3-F393-E0A9-E50E24DCCA9E"), bluetooth.FLAG_WRITE | bluetooth.FLAG_WRITE_NO_RESPONSE,)
_UART_SERVICE = (_UART_UUID, (_UART_RX,),)

class BLEPeripheral:
    def __init__(self, name="LABUBOT"):
        self._ble = bluetooth.BLE()
        self._ble.active(True)
        self._ble.irq(self._irq)
        ((self._handle_rx,),) = self._ble.gatts_register_services((_UART_SERVICE,))

        # Split payload: Name in primary adv, Services in scan response
        self._adv_payload = self._ad_payload(name=name, flags=0x06)
        self._resp_payload = self._ad_payload(services=[_UART_UUID])
        self._advertise()

    def _ad_payload(self, name=None, services=None, flags=None):
        payload = bytearray()
        if flags:
            payload += struct.pack('BB', 2, 0x01) + struct.pack('B', flags)
        if name:
            name_bytes = name.encode('utf-8')
            payload += struct.pack('BB', len(name_bytes) + 1, 0x09) + name_bytes
        if services:
            for s in services:
                b = bytes(s)
                payload += struct.pack('BB', len(b) + 1, 0x07 if len(b) == 16 else 0x03) + b
        return payload

    def _advertise(self, interval_us=500000):
        # Using both adv_data and resp_data to stay under 31-byte limits
        self._ble.gap_advertise(interval_us, adv_data=self._adv_payload, resp_data=self._resp_payload)

    def _irq(self, event, data):
        if event == 1: # CONNECT
            print("BLE Connected")
        elif event == 2: # DISCONNECT
            print("BLE Disconnected")
            self._advertise()
        elif event == 3: # WRITE
            conn_handle, value_handle = data
            if value_handle == self._handle_rx:
                try:
                    raw_msg = self._ble.gatts_read(self._handle_rx).decode()
                    # SPLIT BY NEWLINE: Process multiple commands in one packet to fix lag/crashes
                    for m in raw_msg.strip().split('\n'):
                        if m: handle_command(m.strip())
                except:
                    pass

# =====================
# MOTOR CONTROL
# =====================
def set_motor_speed(left, right):
    def to_duty(val):
        val = max(min(val, 255), -255)
        return int(abs(val) * 257)
    l_duty = to_duty(left)
    r_duty = to_duty(right)
    in1.duty_u16(l_duty if left > 0 else 0)
    in2.duty_u16(l_duty if left < 0 else 0)
    in3.duty_u16(r_duty if right > 0 else 0)
    in4.duty_u16(r_duty if right < 0 else 0)

# =====================
# COMMAND HANDLER
# =====================
def handle_command(value):
    global robot_running, kp, kd, base_speed, pivot_speed
    if not value: return
    cmd = value[0]
    try:
        if cmd == 'T':
            parts = value[1:].split(',')
            l, r = int(parts[0]), int(parts[1])
            robot_running = False
            set_motor_speed(l * 2.5, r * 2.5)
        elif cmd == 'J':
            parts = value[1:].split(',')
            x, y = int(parts[0]), int(parts[1])
            robot_running = False
            set_motor_speed((y + x) * 2.5, (y - x) * 2.5)
        else:
            for part in value.split(' '):
                if not part: continue
                k = part[0]
                v = float(part[1:])
                if k == 'P': kp = v
                elif k == 'D': kd = v
                elif k == 'B': base_speed = int(v)
                elif k == 'V': pivot_speed = int(v)
                elif k == 'S':
                    robot_running = (v > 0.5)
                    if not robot_running: set_motor_speed(0, 0)
    except Exception as e:
        pass

# =====================
# MAIN LINE LOGIC
# =====================
def read_line():
    weighted_sum = 0
    total = 0
    for i in range(6):
        val = 4095 - sensors[i].read()
        weighted_sum += val * weights[i]
        total += val
    return 2500 if total == 0 else weighted_sum // total

# Start BLE
ble = BLEPeripheral()
print("Labubot MicroPython Ready...")

while True:
    if not robot_running:
        time.sleep_ms(10)
        continue
    pos = read_line()
    error = pos - 2500
    if abs(error) < 100: error = 0
    error = max(min(error, 2000), -2000)
    if abs(error) > 1800:
        s = pivot_speed if error > 0 else -pivot_speed
        set_motor_speed(s, -s)
        prev_error = error
        continue
    deriv = (error - prev_error) * 0.5
    pid_val = (kp * error) + (kd * deriv)
    prev_error = error
    max_turn = max(min(70 + abs(error) // 15, 130), 70)
    pid_val = max(min(pid_val, max_turn), -max_turn)
    adj_base = max(min(base_speed - (abs(error) // 10), base_speed), 90)
    set_motor_speed(int(adj_base + pid_val), int(adj_base - pid_val))
    time.sleep_ms(1)
